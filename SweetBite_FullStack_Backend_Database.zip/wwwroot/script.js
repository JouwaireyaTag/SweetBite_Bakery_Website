const API = "/api";
let products = [];
const cart = new Map();

const money = value => `$${Number(value).toFixed(2)}`;

async function loadProducts() {
  const grid = document.getElementById("productGrid");
  try {
    const response = await fetch(`${API}/products`);
    if (!response.ok) throw new Error("Could not load products.");
    products = await response.json();
    renderProducts();
  } catch (error) {
    grid.innerHTML = `<p>We couldn't load products. Make sure the ASP.NET Core app and SQL Server are running, then refresh this page.</p>`;
  }
}

function renderProducts() {
  const grid = document.getElementById("productGrid");
  grid.innerHTML = products.map(product => `
    <article class="product-card">
      <img src="${escapeHtml(product.imageUrl)}" alt="${escapeHtml(product.name)}" loading="lazy">
      <h3>${escapeHtml(product.name)}</h3>
      <p>${escapeHtml(product.description)}</p>
      <div class="price">${money(product.price)}</div>
      <button class="button" data-add="${product.id}">Add to Cart</button>
    </article>`).join("");
  grid.querySelectorAll("[data-add]").forEach(button => {
    button.addEventListener("click", () => addToCart(Number(button.dataset.add)));
  });
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}

function addToCart(productId) {
  const current = cart.get(productId) || 0;
  cart.set(productId, current + 1);
  renderCart();
}

function renderCart() {
  const count = [...cart.values()].reduce((sum, quantity) => sum + quantity, 0);
  document.getElementById("cartCount").textContent = count;
  const summary = document.getElementById("cartSummary");
  const entries = [...cart.entries()];
  if (!entries.length) {
    summary.textContent = "Your cart is empty.";
    return;
  }
  let total = 0;
  summary.innerHTML = entries.map(([id, quantity]) => {
    const product = products.find(p => p.id === id);
    if (!product) return "";
    const lineTotal = Number(product.price) * quantity;
    total += lineTotal;
    return `<div class="cart-row"><span>${escapeHtml(product.name)} × ${quantity}</span><b>${money(lineTotal)}</b></div>`;
  }).join("") + `<hr><div class="cart-row"><b>Total</b><b>${money(total)}</b></div>`;
}

document.getElementById("cartButton").addEventListener("click", () => {
  document.getElementById("contact").scrollIntoView({ behavior: "smooth" });
});

document.getElementById("orderForm").addEventListener("submit", async event => {
  event.preventDefault();
  const message = document.getElementById("formMessage");
  const items = [...cart.entries()].map(([productId, quantity]) => ({ productId, quantity }));
  if (!items.length) {
    message.textContent = "Please add at least one product to your cart first.";
    return;
  }

  const button = event.currentTarget.querySelector("button[type=submit]");
  button.disabled = true;
  message.textContent = "Submitting your order…";
  try {
    const response = await fetch(`${API}/orders`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customerName: document.getElementById("customerName").value,
        customerEmail: document.getElementById("customerEmail").value,
        notes: document.getElementById("notes").value,
        items
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "Order could not be submitted.");
    message.textContent = `Thank you! Demo order #${data.id} saved. Total: ${money(data.total)}.`;
    cart.clear();
    renderCart();
    event.currentTarget.reset();
  } catch (error) {
    message.textContent = error.message || "Something went wrong. Please try again.";
  } finally {
    button.disabled = false;
  }
});

loadProducts();
